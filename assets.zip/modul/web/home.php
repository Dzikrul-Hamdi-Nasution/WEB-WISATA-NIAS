<?php 
$m=$_GET['m'];
switch($m){
	default:
	
		echo '

			
        <!-- Page Heading -->
        <div class="row">
		<div class="col-md-2"></div>
            <div class="col-lg-8">
                <h1 class="page-header">Wisata
                    <small></small>
                </h1>
            </div>
		<div class="col-md-2"></div>
        </div>
        <!-- /.row -->

       ';
		$q=$con->query("SELECT * FROM wisata a, kategori b WHERE a.idKategori=b.idKategori ORDER BY a.idWisata DESC");
		while($r=$q->fetch_object()){ ?>
		
			<div class="row">
			<div class="col-md-2"></div>
            <div class="col-md-3">
                <a href="#">
                    <img style="height:200px;" class="img-responsive" src="<?php echo $site.'assets/file/'.$r->file;?>" alt="">
                </a>
            </div>
            <div class="col-md-5">
                <h3><?php echo $r->namaWisata;?></h3>
                <h4><?php echo $r->areaWisata;?></h4>
                <p>Jam buka: <?php echo $r->jamBuka.'-'.$r->jamTutup;?></p>
                <b class="btn btn-default"><?php echo $r->kategori;?></b>
            </div>
		<div class="col-md-2"></div>
		
		</div>
        <!-- /.row -->
		<br/>
		<?php } 
		
        echo '

        <hr>



        <!-- Pagination --><!--
        <div class="row text-center">
            <div class="col-lg-12">
                <ul class="pagination">
                    <li>
                        <a href="#">«</a>
                    </li>
                    <li class="active">
                        <a href="#">1</a>
                    </li>
                    <li>
                        <a href="#">2</a>
                    </li>
                    <li>
                        <a href="#">3</a>
                    </li>
                    <li>
                        <a href="#">4</a>
                    </li>
                    <li>
                        <a href="#">5</a>
                    </li>
                    <li>
                        <a href="#">»</a>
                    </li>
                </ul>
            </div>-->
			
			';
			
			
		break;
	
		
	
}
?>