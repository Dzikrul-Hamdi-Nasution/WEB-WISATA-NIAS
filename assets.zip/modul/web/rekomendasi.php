<?php 
$m=$_GET['m'];
switch($m){
	default:
	if(isset($_POST['search'])){
			$wni=$_POST['wni'];
			$wna=$_POST['wna'];
			$idKategori=implode("','",$_POST['idKategori']);
			$mulaiTour=$_POST['mulaiTour'];
			$akhirTour=$_POST['akhirTour'];
			
			$q=$con->query("SELECT * FROM wisata a,kategori b WHERE a.idKategori=b.idKategori AND a.idKategori IN ('$idKategori') ORDER BY a.jamTutup ASC, a.popularitas DESC");
			if($q->num_rows<1){
				javascript('rekomendasi','alert','Maaf! Tidak ada rekomendasi wisata');
			}
			
			echo '
			<h2 class="text-center">HASIL REKOMENDASI<br/><small>Keyword Matching</small></h2><hr/>
								
			 <div class="row">
					<div class="col-md-2"></div>
					<div class="col-md-8">
						<h3>Paket Wisata </h3>
					</div>
					<div class="col-md-2"></div>
			
			</div>';
			$i=0;
			while($r=$q->fetch_object()){
				$hWni=$wni*$r->hargaWni;
				$hWna=$wna*$r->hargaWna;
				$total[$i]=$hWni+$hWna;
				$total_orang =$wni+$wna;
				if($total_orang<6){
					$akomodasi=$r->akomodasi_1;
				} 
				if($total_orang>6 and $total_orang<16){
					$akomodasi=$r->akomodasi_2;
				} 
				if($total_orang>16){
					$akomodasi=$r->akomodasi_3;
				} 
				for($j=1;$j<=$r->popularitas;$j++){
					$po[$i][$j]= "<i class='glyphicon glyphicon-star'></i>";
				}
				$p[$i]=implode($po[$i]);
				
				echo "
				
					<div class='row'>
					<div class='col-md-2'></div>
					<div class='col-md-3'>
						<a href='#'>
							<img style='height:200px;' class='img-responsive' src='".$site."assets/file/$r->file' alt=''>
						</a>
					</div>
					<div class='col-md-5'>
						<h3>$r->namaWisata</h3>
						<h4>$r->areaWisata</h4>
						<p>Jam buka: $r->jamBuka-$r->jamTutup</p>
						<p>$p[$i]</p>
						<b class='btn btn-default'> $r->kategori</b>
					</div>
				<div class='col-md-2'></div>
				
				</div>
				<!-- /.row -->
				<br/>
				
			 <div class='row'>
					<div class='col-md-2'></div>
					<div class='col-md-8'>
						<table class='table  table-striped table-bordered'>
						<tr><td><b>Traveler<b></td><td>WNI:$wni orang, WNA:$wna orang</td></tr>
						<tr><td><b>Harga WNI<b></td><td>$wni x ".number_format($r->hargaWni)." = Rp. ".number_format($hWni)." </td></tr>
						<tr><td><b>Harga WNA<b></td><td>$wna x ".number_format($r->hargaWna)." = Rp. ".number_format($hWna)." </td></tr>
						<tr><td><b>Biaya<b></td><td>Rp.".number_format($total[$i])."</td></tr>
						<tr><td><b>Tanggal<b></td><td>$mulaiTour s.d $akhirTour</td></tr>
						<tr><td><b>Akomodasi<b></td><td>$akomodasi</td></tr>
						<tr><td><b>Terdekat<b></td><td>$r->terdekat</td></tr>
						</table>
					</div>
					<div class='col-md-2'></div>
			
			</div>";
			$i++;
			}
			echo "
			 <div class='row'>
					<div class='col-md-2'></div>
					<div class='col-md-8'>
						<table class='table  table-striped table-bordered'>
						
						<tr><td><b>Total Biaya<b></td><td>Rp.".number_format(array_sum($total))."</td></tr>
						<tr><td colspan='2'><a href='".$site."rekomendasi' class='btn btn-primary'>Cari Lagi</a></td></tr>
						</table>
					</div>
					<div class='col-md-2'></div>
			
			</div>";
			
		}else{	
		
		echo '

			<div class="col-lg-12">
			<h2 class="text-center">REKOMENDASI WISATA<br/><small>Keyword Matching</small></h2><hr/>
								<!-- tabs pane-->
								<div class="tab-content">
			
	
    <link href="'.$site.'assets/web/search/css/main.css" rel="stylesheet" />
 
    <div class="s130">
      <form action="" method="POST"  style="width:50%;">
	  <table>
	  <tr>
	  <td style="width:18%;"><label>Jumlah</label></td>
	  <td><input placeholder="wni" name="wni" type="number" class="form-control" value="0" required></td>
	   <td style="width:1%;"></td>
	  <td><input placeholder="wna" name="wna" type="number" class="form-control" value="0" required></td>
	  </tr>
	  <tr><td>
       <label>Kategori</label></td>
	   <td colspan="3">
			';
									$q=$con->query("SELECT * FROM kategori ORDER BY kategori ASC");
									while($r2=$q->fetch_object()){
										echo "<input name='idKategori[]' type='checkbox' value='$r2->idKategori'> $r2->kategori ";
									}
		echo '</td>
	</tr>
	 <tr>
	  <td><label>Tanggal Tour</label></td>
	  <td><input value="'.date('Y-m-d').'"  name="mulaiTour" type="date" class="form-control" required></td>
	   <td style="width:1%;"> - </td>
	  <td><input value="'.date('Y-m-d').'" name="akhirTour" type="date" class="form-control" required></td>
	  </tr>
	  <tr>
	  <td></td>
	  <td colspan="2"><br/><input type="submit" name="search" class="btn btn-primary"></td>
	  </tr>
	</table>
      </form>
    </div>
   

	
			</div> <!-- /panel -->';
		}
			
		break;
	
	
		
	
}
?>