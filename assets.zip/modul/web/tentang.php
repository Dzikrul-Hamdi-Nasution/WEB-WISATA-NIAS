<?php 
$a=$_GET['a'];
switch($a){
	default:
	
	
		
		echo '

			<div class="col-lg-12">
			<h2 class="text-center">TENTANG</h2><hr/>
								<!-- tabs pane-->
								<div class="tab-content">
			<p>
			Aplikasi rekomendasi paket wisata dengan menggunakan Keyword Matching.<br/>
			Panduan<br/>
			<ol>
			<li>Silahkan tentukan preferensi wisata yang Anda butuhkan</li>
			<li>Klik search</li>
			<li>Hasil rekomendasi paket wisata</li>
			</p>
			</div> <!-- /panel -->';
			
			
		break;
	
	
		
	
}
?>