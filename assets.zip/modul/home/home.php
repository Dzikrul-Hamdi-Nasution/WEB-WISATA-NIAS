﻿<?php 
$a=$_SESSION[level];
switch($a){
	case '1':
?>
	
<div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-head-line">DASHBOARD</h1>
                    </div>
             </div>
				
				
				<div class="row">
            <div class="col-lg-12">
				
				 <h3>Selamat Datang di Aplikasi Rekomendasi Tempat Wisata Keyword Matching</h3>
                        <div class="alert alert-info">
                            <strong><u>Panduan:</u></strong><br/>							
							<ol>
							<li>Menu user berguna untuk mengelola user</li>
							<li>Menu kategori berguna untuk mengelola kategori</li>
							<li>Menu wisata berguna untuk mengelola data wisata</li>
							<li>Menu logout berguna untuk keluar aplikasi</li>
							</ol>
						 </div>
						

                        </div>
              
             
            </div>
			
<?php break; ?>

<?php }	?>
    